export class User{
    constructor(
        name:string,
        age:number,
        gender:string,
        mark:number,
        fromplace:string,
    ){}
}